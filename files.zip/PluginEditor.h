#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class ReverbAlgoritmicaAudioProcessorEditor : public juce::AudioProcessorEditor,
                                              private juce::Timer
{
public:
    ReverbAlgoritmicaAudioProcessorEditor(ReverbAlgoritmicaAudioProcessor& p)
        : AudioProcessorEditor(&p), processor(p)
    {
        // Room size
        addAndMakeVisible(roomSizeSlider);
        roomSizeSlider.setRange(0.0, 0.98, 0.01);
        roomSizeSlider.setValue(processor.roomSize.load());
        roomSizeSlider.setTextValueSuffix(" (g)");
        roomSizeSlider.onValueChange = [this] {
            processor.roomSize = (float)roomSizeSlider.getValue();
        };
        addAndMakeVisible(roomSizeLabel);
        roomSizeLabel.setText("Room Size", juce::dontSendNotification);
        roomSizeLabel.attachToComponent(&roomSizeSlider, true);

        // Wet
        addAndMakeVisible(wetSlider);
        wetSlider.setRange(0.0, 1.0, 0.01);
        wetSlider.setValue(processor.wet.load());
        wetSlider.onValueChange = [this] {
            processor.wet = (float)wetSlider.getValue();
        };
        addAndMakeVisible(wetLabel);
        wetLabel.setText("Wet", juce::dontSendNotification);
        wetLabel.attachToComponent(&wetSlider, true);

        // Dry
        addAndMakeVisible(drySlider);
        drySlider.setRange(0.0, 1.0, 0.01);
        drySlider.setValue(processor.dry.load());
        drySlider.onValueChange = [this] {
            processor.dry = (float)drySlider.getValue();
        };
        addAndMakeVisible(dryLabel);
        dryLabel.setText("Dry", juce::dontSendNotification);
        dryLabel.attachToComponent(&drySlider, true);

        setSize(400, 160);
        startTimer(100);
    }

    void paint(juce::Graphics& g) override
    {
        g.fillAll(juce::Colour(0xff0d0f14));
        g.setColour(juce::Colours::white);
        g.setFont(16.0f);
        g.drawFittedText("Reverb Algorítmica — Schroeder",
                         getLocalBounds().removeFromTop(30),
                         juce::Justification::centred, 1);
    }

    void resized() override
    {
        auto area = getLocalBounds().reduced(10);
        area.removeFromTop(30);
        int labelW = 80;
        roomSizeSlider.setBounds(area.removeFromTop(36).withTrimmedLeft(labelW));
        area.removeFromTop(4);
        wetSlider.setBounds(area.removeFromTop(36).withTrimmedLeft(labelW));
        area.removeFromTop(4);
        drySlider.setBounds(area.removeFromTop(36).withTrimmedLeft(labelW));
    }

    void timerCallback() override {}

private:
    ReverbAlgoritmicaAudioProcessor& processor;
    juce::Slider roomSizeSlider, wetSlider, drySlider;
    juce::Label  roomSizeLabel, wetLabel, dryLabel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ReverbAlgoritmicaAudioProcessorEditor)
};
