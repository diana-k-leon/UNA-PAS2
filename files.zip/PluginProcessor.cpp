#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
ReverbAlgoritmicaAudioProcessor::ReverbAlgoritmicaAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput ("Input",  juce::AudioChannelSet::mono(), true)
        .withOutput("Output", juce::AudioChannelSet::mono(), true))
{
    // limpiar buffers
    for (int i = 0; i < 4; ++i)
    {
        memset(combBuffer[i], 0, sizeof(float) * COMB_MAX);
        combWritePtr[i] = 0;
    }
    for (int i = 0; i < 2; ++i)
    {
        memset(apBuffer[i], 0, sizeof(float) * AP_MAX);
        apWritePtr[i] = 0;
    }
}

ReverbAlgoritmicaAudioProcessor::~ReverbAlgoritmicaAudioProcessor() {}

//==============================================================================
void ReverbAlgoritmicaAudioProcessor::prepareToPlay(double sr, int)
{
    sampleRate = sr;

    // limpiar buffers al iniciar
    for (int i = 0; i < 4; ++i)
    {
        memset(combBuffer[i], 0, sizeof(float) * COMB_MAX);
        combWritePtr[i] = 0;
    }
    for (int i = 0; i < 2; ++i)
    {
        memset(apBuffer[i], 0, sizeof(float) * AP_MAX);
        apWritePtr[i] = 0;
    }
}

void ReverbAlgoritmicaAudioProcessor::releaseResources() {}

//==============================================================================
// COMB FILTER
// y[n] = x[n] + g * y[n-D]
// escribimos: buf[w] = input + g * delayed
// output = delayed
float ReverbAlgoritmicaAudioProcessor::processComb(int idx, float input, float g)
{
    int D       = COMB_DELAYS[idx];
    int w       = combWritePtr[idx];
    int N       = COMB_MAX;

    // ① leer el sample retrasado
    int   readPtr = (w - D + N) % N;
    float delayed = combBuffer[idx][readPtr];

    // ② escribir input + feedback
    combBuffer[idx][w] = input + g * delayed;

    // ③ avanzar puntero
    combWritePtr[idx] = (w + 1) % N;

    // ④ output es el sample retrasado
    return delayed;
}

//==============================================================================
// ALLPASS FILTER
// buf_in  = input + g * buf_out
// output  = buf_out - g * buf_in
float ReverbAlgoritmicaAudioProcessor::processAllpass(int idx, float input)
{
    int D = AP_DELAYS[idx];
    int w = apWritePtr[idx];
    int N = AP_MAX;

    // ① leer del buffer
    int   readPtr = (w - D + N) % N;
    float buf_out = apBuffer[idx][readPtr];

    // ② calcular lo que entra al buffer
    float buf_in = input + AP_G * buf_out;

    // ③ escribir en el buffer
    apBuffer[idx][w] = buf_in;

    // ④ avanzar puntero
    apWritePtr[idx] = (w + 1) % N;

    // ⑤ output = feedforward negativo + delayed
    return buf_out - AP_G * buf_in;
}

//==============================================================================
void ReverbAlgoritmicaAudioProcessor::processBlock(
    juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    float g   = juce::jlimit(0.0f, 0.98f, roomSize.load());
    float wetG = wet.load();
    float dryG = dry.load();

    auto* data = buffer.getWritePointer(0);
    int   numSamples = buffer.getNumSamples();

    for (int n = 0; n < numSamples; ++n)
    {
        float input = data[n];

        // --- 4 combs en PARALELO — sumamos sus salidas ---
        float combSum = 0.0f;
        for (int i = 0; i < 4; ++i)
            combSum += processComb(i, input, g);

        // escalar la suma (promedio de 4 combs)
        combSum *= 0.25f;

        // --- 2 allpass en SERIE ---
        float rev = processAllpass(0, combSum);
        rev        = processAllpass(1, rev);

        // --- mezcla dry + wet ---
        data[n] = dryG * input + wetG * rev;
    }
}

//==============================================================================
juce::AudioProcessorEditor* ReverbAlgoritmicaAudioProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ReverbAlgoritmicaAudioProcessor();
}
